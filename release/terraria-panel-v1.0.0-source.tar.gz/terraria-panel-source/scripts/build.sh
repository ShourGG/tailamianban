#!/bin/bash

# Terraria Panel Build Script
# This script builds the frontend and prepares for single-port deployment

echo "🎮 Building Terraria Panel..."

# Step 1: Build frontend
echo "📦 Building frontend..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Frontend build failed!"
    exit 1
fi

# Step 2: Copy dist to backend
echo "📁 Copying frontend dist to backend..."
rm -rf backend/dist
cp -r dist backend/

# Step 3: Build backend
echo "🔧 Building backend..."
cd backend
go build -o terraria-panel cmd/main.go

if [ $? -ne 0 ]; then
    echo "❌ Backend build failed!"
    exit 1
fi

echo "✅ Build completed successfully!"
echo ""
echo "🚀 To run the single-port server:"
echo "   cd backend"
echo "   ./terraria-panel"
echo ""
echo "🌐 Access the panel at: http://localhost:8080"
